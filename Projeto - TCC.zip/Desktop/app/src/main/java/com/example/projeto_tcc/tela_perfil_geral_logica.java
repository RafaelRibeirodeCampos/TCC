package com.example.projeto_tcc;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_perfil_geral_logica extends AppCompatActivity {
    Spinner opcoesPG;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.tela_perfil_geral);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.btnSalvarHR), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        opcoesPG = findViewById(R.id.spnPG);
        String [] respPG = {"A", "B", "C", "D", "E", "F"};
        ArrayAdapter<String> selecao = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                respPG
        );
        selecao.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        opcoesPG.setAdapter(selecao);
        opcoesPG.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item_selecionado = parent.getItemAtPosition(position).toString();
                Toast.makeText(tela_perfil_geral_logica.this, "Selecionado: " + item_selecionado, Toast.LENGTH_SHORT).show();
            }
        });
    }
}