package com.example.projeto_tcc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_forms_logica extends AppCompatActivity {
    Button botao_PG_var;
    Button botao_RA_var;
    Button botao_PA_var;
    Button botao_HR_var;
    Button botao_EF_var;
    Button botao_enviar_var;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.tela_forms);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        botao_PG_var = findViewById(R.id.btnPG);
        botao_RA_var = findViewById(R.id.btnRA);
        botao_PA_var = findViewById(R.id.btnPA);
        botao_HR_var = findViewById(R.id.btnHR);
        botao_EF_var = findViewById(R.id.btnEF);
        botao_enviar_var = findViewById(R.id.btnEnviar);
        botao_PG_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela_PG = new Intent(tela_forms_logica.this, tela_perfil_geral_logica.class);
                startActivity(tela_PG);
            }
        });
        botao_RA_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela_RA = new Intent(tela_forms_logica.this, tela_resticoes_alimentares_logica.class);
                startActivity(tela_RA);
            }
        });
        botao_PA_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela_PA = new Intent(tela_forms_logica.this, tela_preferencias_alimentares_logica.class);
                startActivity(tela_PA);
            }
        });
        botao_HR_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela_HR = new Intent(tela_forms_logica.this, tela_habitos_rotina_logica.class);
                startActivity(tela_HR);
            }
        });
        botao_EF_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela_EF = new Intent(tela_forms_logica.this, tela_expectativas_flexibilidade_logica.class);
                startActivity(tela_EF);
            }
        });
    }
}