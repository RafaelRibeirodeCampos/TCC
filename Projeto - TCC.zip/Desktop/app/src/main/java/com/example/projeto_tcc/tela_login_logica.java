package com.example.projeto_tcc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela_login_logica extends AppCompatActivity {
    Button botao_var;
    Button botao_var_2;
    EditText nome_var;
    EditText senha_var;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.tela_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        String nome_var_2 = nome_var.getText().toString();
        String senha_var_2 = senha_var.getText().toString();
        botao_var = findViewById(R.id.btnEntrar);
        botao_var_2 = findViewById(R.id.btnCriar);
        botao_var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nome_var_2.isEmpty()){
                    Toast.makeText(tela_login_logica.this, "Informe seu Nome de Usuário", Toast.LENGTH_SHORT).show();
                } else if (senha_var_2.isEmpty()) {
                    Toast.makeText(tela_login_logica.this, "Digite sua Senha", Toast.LENGTH_SHORT).show();
                } else  {
                    Intent mudar_tela_e = new Intent(tela_login_logica.this, tela_login_logica.class);

                    startActivity(mudar_tela_e);
                }
            }
        });
        botao_var_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mudar_tela_c = new Intent(tela_login_logica.this, tela_cadastro_logica.class);

                startActivity(mudar_tela_c);
            }
        });
    }
}